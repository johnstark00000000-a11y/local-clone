# Neural Clone Protocol (NCP-09)

Advanced **human-brain-cloning simulation lab** built with **Python + Django**.  
This is a software demo (not a biological system): capture a subject, run a connectome pipeline, and stabilize a “clone” record.

Works locally, on **GitHub**, and on **Render**.

## Features

- Dark sci-fi control room UI
- Initiate clone sequences (architecture, fidelity, notes)
- Lab queue + clone detail dashboard
- Multi-stage pipeline: queued → scanning → mapping → encoding → stabilizing → ready
- Health check at `/health/` for Render
- WhiteNoise static files, Gunicorn, PostgreSQL-ready settings

## Local run

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser   # optional, /admin/
python manage.py runserver
```

Open http://127.0.0.1:8000/

## GitHub

```bash
cd neural-clone
git init
git add .
git commit -m "Initial Neural Clone Protocol"
git branch -M main
git remote add origin https://github.com/YOUR_USER/neural-clone.git
git push -u origin main
```

## Deploy on Render

1. Push this repo to GitHub.
2. In [Render](https://render.com) → **New → Blueprint** and point at the repo  
   **or** **New Web Service** → connect the GitHub repo.
3. Settings if you do not use `render.yaml`:
   - **Runtime:** Python 3
   - **Build:** `pip install -r requirements.txt && python manage.py collectstatic --noinput && python manage.py migrate`
   - **Start:** `gunicorn neuralclone.wsgi:application --bind 0.0.0.0:$PORT`
4. Environment variables:
   - `DJANGO_SECRET_KEY` — generate a long random string
   - `DJANGO_DEBUG` — `False`
   - `ALLOWED_HOSTS` — `.onrender.com` (or your custom domain)
   - `DATABASE_URL` — add a Render PostgreSQL instance and copy the URL (optional; SQLite works on a single instance but is not durable)
5. Deploy. Health path: `/health/`

## Project layout

```
neural-clone/
  manage.py
  requirements.txt
  Procfile
  render.yaml
  neuralclone/          # Django project
  clone/                # app: models, views, templates
```

## Admin

After `createsuperuser`, manage clone records at `/admin/`.
